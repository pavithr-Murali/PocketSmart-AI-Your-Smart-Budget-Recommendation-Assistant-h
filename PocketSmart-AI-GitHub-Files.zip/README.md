# PocketSmart AI 💰

PocketSmart AI is a smart budget and recommendation assistant.

## Features
- Enter monthly income
- Enter monthly expenses
- Calculate remaining balance
- Calculate savings percentage
- Give a simple budget recommendation

## Files
- `index.html` - Website structure
- `style.css` - Website design
- `script.js` - Budget calculation and recommendation logic

## Future AI Features
- AI-powered spending recommendations
- Expense category analysis
- Personalized saving plans
- Gemini/Generative AI integration
