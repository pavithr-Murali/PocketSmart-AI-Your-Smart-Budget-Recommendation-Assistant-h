function analyzeBudget() {
  const income = Number(document.getElementById("income").value);
  const expenses = Number(document.getElementById("expenses").value);
  const result = document.getElementById("result");

  if (!income || income <= 0 || expenses < 0) {
    result.innerHTML = "Please enter valid income and expense amounts.";
    return;
  }

  const savings = income - expenses;
  const savingsPercent = (savings / income) * 100;

  let recommendation = "";

  if (savings < 0) {
    recommendation = "Your expenses are higher than your income. Try reducing non-essential spending.";
  } else if (savingsPercent < 20) {
    recommendation = "Try to increase your savings by reducing unnecessary expenses.";
  } else {
    recommendation = "Your budget has a positive balance. Consider saving or investing part of it.";
  }

  result.innerHTML = `
    <strong>Budget Summary</strong><br>
    Income: ₹${income.toLocaleString()}<br>
    Expenses: ₹${expenses.toLocaleString()}<br>
    Balance: ₹${savings.toLocaleString()}<br>
    Savings Rate: ${savingsPercent.toFixed(1)}%<br><br>
    <strong>Recommendation:</strong><br>
    ${recommendation}
  `;
}
